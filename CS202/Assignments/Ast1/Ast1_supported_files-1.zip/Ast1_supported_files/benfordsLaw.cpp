
#include <iostream>
#include <iomanip>
#include <math.h>
#include <string>
#include <cstring>
#include <fstream>
#include <sstream>
using namespace std;

/**
 * @brief findFirstDigit : Calculate the first digit of the given number
 * @param number
 */

int findFirstDigit(int number)
{
        return number;                       // return first digit
}

/**
 * @brief findHundreds : Read the value from the second parameter and calculate the 
 * number of 100's of a given value
 *&param value- value passed from main() like the total count of 0's 
 * in the given input file
 * &param ofstream &resultFile- print the number of asterisks(stars) based on the calculated value 
 * and also return value to the output file
 */
int findHundreds(ofstream &resultFile, double value)
{
        return value; //return hundreds value; if value=220; then it should return 22
}
int main(int argc, char *argv[])
{
    return 0;
}